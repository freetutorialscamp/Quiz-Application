/* Creating an array an passing number, questions, options and answers */
let questions = [
    {
        numb: 1,
        question: "What does HTML stand for?",
        answer: "Hyper Text Markup Language",
        options: [
            "Hyper Text Markup Language",
            "Hyper Text Preprocessor",
            "Hyper Text Modeling Language",
            "Hyper Type Multiple Language"
        ]
    },
    {
        numb: 2,
        question: "What does CSS stand for?",
        answer: "Cascading Style Sheet",
        options: [
            "Coding Style Sheet",
            "Cascading Styling Sheet",
            "Cascading Style Sheet",
            "Comanding Style Sheet"
        ]
    },
    {
        numb: 3,
        question: "What does PHP stand for?",
        answer: "Hypertext Preprocessor",
        options: [
            "Hypertext Preprocessor",
            "Hypertext Precoding",
            "Hypertext Program",
            "Highly Preprocessor"
        ]
    },
    {
        numb: 4,
        question: "What does SQL stand for?",
        answer: "Structured Query Language",
        options: [
            "Styling Query Language",
            "Style Query Language",
            "Start Question Language",
            "Structured Query Language"
        ]
    },
    {
        numb: 5,
        question: "What does XML stand for?",
        answer: "eXtensible Markup Language",
        options: [
            "eXtensible Multi Language",
            "eXtensible Markup Language",
            "eXtra Markup Language",
            "eXample Multiple Language"
        ]
    },
];